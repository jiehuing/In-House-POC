﻿namespace WindowsFormsApp1
{
    partial class SearchData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labelSearchData = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelBB = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textSiOfferBid = new System.Windows.Forms.TextBox();
            this.textOyaOfferBid = new System.Windows.Forms.TextBox();
            this.textSmaOfferBid = new System.Windows.Forms.TextBox();
            this.textOmaOfferBid = new System.Windows.Forms.TextBox();
            this.textYtdOfferBid = new System.Windows.Forms.TextBox();
            this.textOmaBenchmark = new System.Windows.Forms.TextBox();
            this.textSiBenchmark = new System.Windows.Forms.TextBox();
            this.textOmaBidBid = new System.Windows.Forms.TextBox();
            this.textTmaBidBid = new System.Windows.Forms.TextBox();
            this.textSmaBidBid = new System.Windows.Forms.TextBox();
            this.labelSI = new System.Windows.Forms.Label();
            this.textOyaBidBid = new System.Windows.Forms.TextBox();
            this.labelSM = new System.Windows.Forms.Label();
            this.labelOM = new System.Windows.Forms.Label();
            this.labelOB = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelPH = new System.Windows.Forms.Label();
            this.labelYtd = new System.Windows.Forms.Label();
            this.textOyaBenchmark = new System.Windows.Forms.TextBox();
            this.textSmaBenchmark = new System.Windows.Forms.TextBox();
            this.textTmaBenchmark = new System.Windows.Forms.TextBox();
            this.textYtdBenchmark = new System.Windows.Forms.TextBox();
            this.labelTM = new System.Windows.Forms.Label();
            this.textSiBidBid = new System.Windows.Forms.TextBox();
            this.labelOY = new System.Windows.Forms.Label();
            this.textTmaOfferBid = new System.Windows.Forms.TextBox();
            this.textYtdBidBid = new System.Windows.Forms.TextBox();
            this.textSearchDate = new System.Windows.Forms.TextBox();
            this.textOyaNav = new System.Windows.Forms.TextBox();
            this.textSearchNav = new System.Windows.Forms.TextBox();
            this.textSmaNav = new System.Windows.Forms.TextBox();
            this.textTmaNav = new System.Windows.Forms.TextBox();
            this.textOmaNav = new System.Windows.Forms.TextBox();
            this.textYtdNav = new System.Windows.Forms.TextBox();
            this.textSiNav = new System.Windows.Forms.TextBox();
            this.textInceptYear = new System.Windows.Forms.TextBox();
            this.textSearchBi = new System.Windows.Forms.TextBox();
            this.textSiBi = new System.Windows.Forms.TextBox();
            this.textYtdBi = new System.Windows.Forms.TextBox();
            this.textOmaBi = new System.Windows.Forms.TextBox();
            this.textTmaBi = new System.Windows.Forms.TextBox();
            this.textOyaBi = new System.Windows.Forms.TextBox();
            this.textSmaBi = new System.Windows.Forms.TextBox();
            this.textLevy = new System.Windows.Forms.TextBox();
            this.textSearchOffer = new System.Windows.Forms.TextBox();
            this.textOyaOffer = new System.Windows.Forms.TextBox();
            this.textSmaOffer = new System.Windows.Forms.TextBox();
            this.textTmaOffer = new System.Windows.Forms.TextBox();
            this.textOmaOffer = new System.Windows.Forms.TextBox();
            this.textYtdOffer = new System.Windows.Forms.TextBox();
            this.textSiOffer = new System.Windows.Forms.TextBox();
            this.textSiDate = new System.Windows.Forms.TextBox();
            this.textInceptMonth = new System.Windows.Forms.TextBox();
            this.textNav = new System.Windows.Forms.TextBox();
            this.textBi = new System.Windows.Forms.TextBox();
            this.labelBenchmarkLegendColour = new System.Windows.Forms.Label();
            this.labelBidBidLegendColour = new System.Windows.Forms.Label();
            this.labelBenchmarkLegendText = new System.Windows.Forms.Label();
            this.labelBidBidLegendText = new System.Windows.Forms.Label();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.labelPO = new System.Windows.Forms.Label();
            this.labelIndex = new System.Windows.Forms.Label();
            this.labelSBText = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textFifthHSectorPercent = new System.Windows.Forms.TextBox();
            this.textFourthHSectorPercent = new System.Windows.Forms.TextBox();
            this.textTHSectorPercent = new System.Windows.Forms.TextBox();
            this.textSHSectorPercent = new System.Windows.Forms.TextBox();
            this.textFHSectorPercent = new System.Windows.Forms.TextBox();
            this.textFHSector = new System.Windows.Forms.TextBox();
            this.textFifthHName = new System.Windows.Forms.TextBox();
            this.textFHName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textSHName = new System.Windows.Forms.TextBox();
            this.textFourthHName = new System.Windows.Forms.TextBox();
            this.textTHName = new System.Windows.Forms.TextBox();
            this.textSHSector = new System.Windows.Forms.TextBox();
            this.textTHSector = new System.Windows.Forms.TextBox();
            this.textFourthHSector = new System.Windows.Forms.TextBox();
            this.textFifthHSector = new System.Windows.Forms.TextBox();
            this.labelTH = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.textTotalPercent = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(114, 881);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 49);
            this.button3.TabIndex = 6;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1684, 881);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 49);
            this.button1.TabIndex = 7;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelSearchData
            // 
            this.labelSearchData.AutoSize = true;
            this.labelSearchData.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelSearchData.Location = new System.Drawing.Point(816, 31);
            this.labelSearchData.Name = "labelSearchData";
            this.labelSearchData.Size = new System.Drawing.Size(187, 32);
            this.labelSearchData.TabIndex = 8;
            this.labelSearchData.Text = "Prestige Data";
            this.labelSearchData.Click += new System.EventHandler(this.label1_Click);
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(132, 260);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Bid-Bid";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(708, 453);
            this.chart1.TabIndex = 12;
            this.chart1.Text = "chart1";
            // 
            // labelDate
            // 
            this.labelDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(796, 104);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(44, 20);
            this.labelDate.TabIndex = 13;
            this.labelDate.Text = "Date";
            this.labelDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelDate.Click += new System.EventHandler(this.label2_Click);
            // 
            // labelBB
            // 
            this.labelBB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelBB.AutoSize = true;
            this.labelBB.Location = new System.Drawing.Point(4, 63);
            this.labelBB.Name = "labelBB";
            this.labelBB.Size = new System.Drawing.Size(109, 40);
            this.labelBB.TabIndex = 14;
            this.labelBB.Text = "Bid-Bid (%)";
            this.labelBB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelBB.Click += new System.EventHandler(this.labelBb_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.68016F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.31984F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 101F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 148F));
            this.tableLayoutPanel1.Controls.Add(this.textSiOfferBid, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.textOyaOfferBid, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.textSmaOfferBid, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.textOmaOfferBid, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textYtdOfferBid, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textOmaBenchmark, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.textSiBenchmark, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.textOmaBidBid, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.textTmaBidBid, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.textSmaBidBid, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelSI, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.textOyaBidBid, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelSM, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelOM, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelOB, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelB, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelPH, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelBB, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelYtd, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textOyaBenchmark, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.textSmaBenchmark, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.textTmaBenchmark, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.textYtdBenchmark, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelTM, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.textSiBidBid, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelOY, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.textTmaOfferBid, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textYtdBidBid, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1019, 351);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.74767F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.25233F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(770, 182);
            this.tableLayoutPanel1.TabIndex = 18;
            // 
            // textSiOfferBid
            // 
            this.textSiOfferBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSiOfferBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textSiOfferBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSiOfferBid.Location = new System.Drawing.Point(623, 107);
            this.textSiOfferBid.Name = "textSiOfferBid";
            this.textSiOfferBid.Size = new System.Drawing.Size(143, 19);
            this.textSiOfferBid.TabIndex = 45;
            this.textSiOfferBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textOyaOfferBid
            // 
            this.textOyaOfferBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textOyaOfferBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textOyaOfferBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textOyaOfferBid.Location = new System.Drawing.Point(517, 107);
            this.textOyaOfferBid.Name = "textOyaOfferBid";
            this.textOyaOfferBid.Size = new System.Drawing.Size(99, 19);
            this.textOyaOfferBid.TabIndex = 44;
            this.textOyaOfferBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textSmaOfferBid
            // 
            this.textSmaOfferBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSmaOfferBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textSmaOfferBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSmaOfferBid.Location = new System.Drawing.Point(415, 107);
            this.textSmaOfferBid.Name = "textSmaOfferBid";
            this.textSmaOfferBid.Size = new System.Drawing.Size(95, 19);
            this.textSmaOfferBid.TabIndex = 43;
            this.textSmaOfferBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textOmaOfferBid
            // 
            this.textOmaOfferBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textOmaOfferBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textOmaOfferBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textOmaOfferBid.Location = new System.Drawing.Point(209, 107);
            this.textOmaOfferBid.Name = "textOmaOfferBid";
            this.textOmaOfferBid.Size = new System.Drawing.Size(95, 19);
            this.textOmaOfferBid.TabIndex = 41;
            this.textOmaOfferBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textYtdOfferBid
            // 
            this.textYtdOfferBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textYtdOfferBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textYtdOfferBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textYtdOfferBid.Location = new System.Drawing.Point(120, 107);
            this.textYtdOfferBid.Name = "textYtdOfferBid";
            this.textYtdOfferBid.Size = new System.Drawing.Size(82, 19);
            this.textYtdOfferBid.TabIndex = 40;
            this.textYtdOfferBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textOmaBenchmark
            // 
            this.textOmaBenchmark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textOmaBenchmark.BackColor = System.Drawing.Color.Gainsboro;
            this.textOmaBenchmark.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textOmaBenchmark.Location = new System.Drawing.Point(209, 147);
            this.textOmaBenchmark.Name = "textOmaBenchmark";
            this.textOmaBenchmark.Size = new System.Drawing.Size(95, 19);
            this.textOmaBenchmark.TabIndex = 38;
            this.textOmaBenchmark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textSiBenchmark
            // 
            this.textSiBenchmark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSiBenchmark.BackColor = System.Drawing.Color.Gainsboro;
            this.textSiBenchmark.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSiBenchmark.Location = new System.Drawing.Point(623, 147);
            this.textSiBenchmark.Name = "textSiBenchmark";
            this.textSiBenchmark.Size = new System.Drawing.Size(143, 19);
            this.textSiBenchmark.TabIndex = 37;
            this.textSiBenchmark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textOmaBidBid
            // 
            this.textOmaBidBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textOmaBidBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textOmaBidBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textOmaBidBid.Location = new System.Drawing.Point(209, 66);
            this.textOmaBidBid.Name = "textOmaBidBid";
            this.textOmaBidBid.Size = new System.Drawing.Size(95, 19);
            this.textOmaBidBid.TabIndex = 33;
            this.textOmaBidBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textTmaBidBid
            // 
            this.textTmaBidBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTmaBidBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textTmaBidBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTmaBidBid.Location = new System.Drawing.Point(311, 66);
            this.textTmaBidBid.Name = "textTmaBidBid";
            this.textTmaBidBid.Size = new System.Drawing.Size(97, 19);
            this.textTmaBidBid.TabIndex = 33;
            this.textTmaBidBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textSmaBidBid
            // 
            this.textSmaBidBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSmaBidBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textSmaBidBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSmaBidBid.Location = new System.Drawing.Point(415, 66);
            this.textSmaBidBid.Name = "textSmaBidBid";
            this.textSmaBidBid.Size = new System.Drawing.Size(95, 19);
            this.textSmaBidBid.TabIndex = 33;
            this.textSmaBidBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelSI
            // 
            this.labelSI.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelSI.AutoSize = true;
            this.labelSI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSI.Location = new System.Drawing.Point(623, 1);
            this.labelSI.Name = "labelSI";
            this.labelSI.Size = new System.Drawing.Size(143, 61);
            this.labelSI.TabIndex = 25;
            this.labelSI.Text = "Since Inception (p.a.)";
            this.labelSI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textOyaBidBid
            // 
            this.textOyaBidBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textOyaBidBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textOyaBidBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textOyaBidBid.Location = new System.Drawing.Point(517, 66);
            this.textOyaBidBid.Name = "textOyaBidBid";
            this.textOyaBidBid.Size = new System.Drawing.Size(99, 19);
            this.textOyaBidBid.TabIndex = 24;
            this.textOyaBidBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textOyaBidBid.TextChanged += new System.EventHandler(this.textOyaBidBid_TextChanged);
            // 
            // labelSM
            // 
            this.labelSM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelSM.AutoSize = true;
            this.labelSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSM.Location = new System.Drawing.Point(415, 1);
            this.labelSM.Name = "labelSM";
            this.labelSM.Size = new System.Drawing.Size(95, 61);
            this.labelSM.TabIndex = 23;
            this.labelSM.Text = "6 Months";
            this.labelSM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelOM
            // 
            this.labelOM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelOM.AutoSize = true;
            this.labelOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOM.Location = new System.Drawing.Point(209, 1);
            this.labelOM.Name = "labelOM";
            this.labelOM.Size = new System.Drawing.Size(95, 61);
            this.labelOM.TabIndex = 21;
            this.labelOM.Text = "1 Month";
            this.labelOM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelOB
            // 
            this.labelOB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelOB.AutoSize = true;
            this.labelOB.Location = new System.Drawing.Point(4, 104);
            this.labelOB.Name = "labelOB";
            this.labelOB.Size = new System.Drawing.Size(109, 39);
            this.labelOB.TabIndex = 17;
            this.labelOB.Text = "Offer-Bid (%)";
            this.labelOB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelB
            // 
            this.labelB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelB.AutoSize = true;
            this.labelB.Location = new System.Drawing.Point(4, 144);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(109, 37);
            this.labelB.TabIndex = 18;
            this.labelB.Text = "Benchmark (%)";
            this.labelB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelPH
            // 
            this.labelPH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelPH.AutoSize = true;
            this.labelPH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPH.Location = new System.Drawing.Point(4, 1);
            this.labelPH.Name = "labelPH";
            this.labelPH.Size = new System.Drawing.Size(109, 61);
            this.labelPH.TabIndex = 19;
            this.labelPH.Text = "Performance History";
            this.labelPH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelYtd
            // 
            this.labelYtd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelYtd.AutoSize = true;
            this.labelYtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelYtd.Location = new System.Drawing.Point(120, 1);
            this.labelYtd.Name = "labelYtd";
            this.labelYtd.Size = new System.Drawing.Size(82, 61);
            this.labelYtd.TabIndex = 20;
            this.labelYtd.Text = "Year to Date";
            this.labelYtd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textOyaBenchmark
            // 
            this.textOyaBenchmark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textOyaBenchmark.BackColor = System.Drawing.Color.Gainsboro;
            this.textOyaBenchmark.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textOyaBenchmark.Location = new System.Drawing.Point(517, 147);
            this.textOyaBenchmark.Name = "textOyaBenchmark";
            this.textOyaBenchmark.Size = new System.Drawing.Size(99, 19);
            this.textOyaBenchmark.TabIndex = 34;
            this.textOyaBenchmark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textSmaBenchmark
            // 
            this.textSmaBenchmark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSmaBenchmark.BackColor = System.Drawing.Color.Gainsboro;
            this.textSmaBenchmark.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSmaBenchmark.Location = new System.Drawing.Point(415, 147);
            this.textSmaBenchmark.Name = "textSmaBenchmark";
            this.textSmaBenchmark.Size = new System.Drawing.Size(95, 19);
            this.textSmaBenchmark.TabIndex = 35;
            this.textSmaBenchmark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textTmaBenchmark
            // 
            this.textTmaBenchmark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTmaBenchmark.BackColor = System.Drawing.Color.Gainsboro;
            this.textTmaBenchmark.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTmaBenchmark.Location = new System.Drawing.Point(311, 147);
            this.textTmaBenchmark.Name = "textTmaBenchmark";
            this.textTmaBenchmark.Size = new System.Drawing.Size(97, 19);
            this.textTmaBenchmark.TabIndex = 36;
            this.textTmaBenchmark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textYtdBenchmark
            // 
            this.textYtdBenchmark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textYtdBenchmark.BackColor = System.Drawing.Color.Gainsboro;
            this.textYtdBenchmark.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textYtdBenchmark.Location = new System.Drawing.Point(120, 147);
            this.textYtdBenchmark.Name = "textYtdBenchmark";
            this.textYtdBenchmark.Size = new System.Drawing.Size(82, 19);
            this.textYtdBenchmark.TabIndex = 39;
            this.textYtdBenchmark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelTM
            // 
            this.labelTM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelTM.AutoSize = true;
            this.labelTM.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTM.Location = new System.Drawing.Point(311, 1);
            this.labelTM.Name = "labelTM";
            this.labelTM.Size = new System.Drawing.Size(97, 61);
            this.labelTM.TabIndex = 22;
            this.labelTM.Text = "3 Months";
            this.labelTM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textSiBidBid
            // 
            this.textSiBidBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSiBidBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textSiBidBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSiBidBid.Location = new System.Drawing.Point(623, 66);
            this.textSiBidBid.Name = "textSiBidBid";
            this.textSiBidBid.Size = new System.Drawing.Size(143, 19);
            this.textSiBidBid.TabIndex = 33;
            this.textSiBidBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelOY
            // 
            this.labelOY.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelOY.AutoSize = true;
            this.labelOY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOY.Location = new System.Drawing.Point(517, 1);
            this.labelOY.Name = "labelOY";
            this.labelOY.Size = new System.Drawing.Size(99, 61);
            this.labelOY.TabIndex = 24;
            this.labelOY.Text = "1 Year";
            this.labelOY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textTmaOfferBid
            // 
            this.textTmaOfferBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTmaOfferBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textTmaOfferBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTmaOfferBid.Location = new System.Drawing.Point(311, 107);
            this.textTmaOfferBid.Name = "textTmaOfferBid";
            this.textTmaOfferBid.Size = new System.Drawing.Size(97, 19);
            this.textTmaOfferBid.TabIndex = 42;
            this.textTmaOfferBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textYtdBidBid
            // 
            this.textYtdBidBid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textYtdBidBid.BackColor = System.Drawing.Color.Gainsboro;
            this.textYtdBidBid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textYtdBidBid.Location = new System.Drawing.Point(120, 66);
            this.textYtdBidBid.Name = "textYtdBidBid";
            this.textYtdBidBid.Size = new System.Drawing.Size(82, 19);
            this.textYtdBidBid.TabIndex = 33;
            this.textYtdBidBid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textYtdBidBid.TextChanged += new System.EventHandler(this.textYtdBidBid_TextChanged);
            // 
            // textSearchDate
            // 
            this.textSearchDate.Location = new System.Drawing.Point(849, 102);
            this.textSearchDate.Name = "textSearchDate";
            this.textSearchDate.Size = new System.Drawing.Size(158, 26);
            this.textSearchDate.TabIndex = 19;
            this.textSearchDate.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textOyaNav
            // 
            this.textOyaNav.Location = new System.Drawing.Point(28, 12);
            this.textOyaNav.Name = "textOyaNav";
            this.textOyaNav.Size = new System.Drawing.Size(10, 26);
            this.textOyaNav.TabIndex = 23;
            this.textOyaNav.Visible = false;
            this.textOyaNav.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // textSearchNav
            // 
            this.textSearchNav.Location = new System.Drawing.Point(12, 12);
            this.textSearchNav.Name = "textSearchNav";
            this.textSearchNav.Size = new System.Drawing.Size(10, 26);
            this.textSearchNav.TabIndex = 27;
            this.textSearchNav.Visible = false;
            this.textSearchNav.TextChanged += new System.EventHandler(this.textCurrentNav_TextChanged);
            // 
            // textSmaNav
            // 
            this.textSmaNav.Location = new System.Drawing.Point(44, 12);
            this.textSmaNav.Name = "textSmaNav";
            this.textSmaNav.Size = new System.Drawing.Size(10, 26);
            this.textSmaNav.TabIndex = 28;
            this.textSmaNav.Visible = false;
            this.textSmaNav.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // textTmaNav
            // 
            this.textTmaNav.Location = new System.Drawing.Point(60, 12);
            this.textTmaNav.Name = "textTmaNav";
            this.textTmaNav.Size = new System.Drawing.Size(10, 26);
            this.textTmaNav.TabIndex = 29;
            this.textTmaNav.Visible = false;
            // 
            // textOmaNav
            // 
            this.textOmaNav.Location = new System.Drawing.Point(76, 12);
            this.textOmaNav.Name = "textOmaNav";
            this.textOmaNav.Size = new System.Drawing.Size(10, 26);
            this.textOmaNav.TabIndex = 30;
            this.textOmaNav.Visible = false;
            // 
            // textYtdNav
            // 
            this.textYtdNav.Location = new System.Drawing.Point(92, 12);
            this.textYtdNav.Name = "textYtdNav";
            this.textYtdNav.Size = new System.Drawing.Size(10, 26);
            this.textYtdNav.TabIndex = 31;
            this.textYtdNav.Visible = false;
            // 
            // textSiNav
            // 
            this.textSiNav.Location = new System.Drawing.Point(108, 12);
            this.textSiNav.Name = "textSiNav";
            this.textSiNav.Size = new System.Drawing.Size(10, 26);
            this.textSiNav.TabIndex = 32;
            this.textSiNav.Visible = false;
            // 
            // textInceptYear
            // 
            this.textInceptYear.Location = new System.Drawing.Point(1013, 102);
            this.textInceptYear.Name = "textInceptYear";
            this.textInceptYear.Size = new System.Drawing.Size(10, 26);
            this.textInceptYear.TabIndex = 33;
            this.textInceptYear.Visible = false;
            // 
            // textSearchBi
            // 
            this.textSearchBi.Location = new System.Drawing.Point(12, 76);
            this.textSearchBi.Name = "textSearchBi";
            this.textSearchBi.Size = new System.Drawing.Size(10, 26);
            this.textSearchBi.TabIndex = 35;
            this.textSearchBi.Visible = false;
            // 
            // textSiBi
            // 
            this.textSiBi.Location = new System.Drawing.Point(108, 76);
            this.textSiBi.Name = "textSiBi";
            this.textSiBi.Size = new System.Drawing.Size(10, 26);
            this.textSiBi.TabIndex = 36;
            this.textSiBi.Visible = false;
            // 
            // textYtdBi
            // 
            this.textYtdBi.Location = new System.Drawing.Point(92, 76);
            this.textYtdBi.Name = "textYtdBi";
            this.textYtdBi.Size = new System.Drawing.Size(10, 26);
            this.textYtdBi.TabIndex = 37;
            this.textYtdBi.Visible = false;
            // 
            // textOmaBi
            // 
            this.textOmaBi.Location = new System.Drawing.Point(76, 76);
            this.textOmaBi.Name = "textOmaBi";
            this.textOmaBi.Size = new System.Drawing.Size(10, 26);
            this.textOmaBi.TabIndex = 38;
            this.textOmaBi.Visible = false;
            // 
            // textTmaBi
            // 
            this.textTmaBi.Location = new System.Drawing.Point(60, 76);
            this.textTmaBi.Name = "textTmaBi";
            this.textTmaBi.Size = new System.Drawing.Size(10, 26);
            this.textTmaBi.TabIndex = 39;
            this.textTmaBi.Visible = false;
            // 
            // textOyaBi
            // 
            this.textOyaBi.Location = new System.Drawing.Point(28, 76);
            this.textOyaBi.Name = "textOyaBi";
            this.textOyaBi.Size = new System.Drawing.Size(10, 26);
            this.textOyaBi.TabIndex = 40;
            this.textOyaBi.Visible = false;
            // 
            // textSmaBi
            // 
            this.textSmaBi.Location = new System.Drawing.Point(44, 76);
            this.textSmaBi.Name = "textSmaBi";
            this.textSmaBi.Size = new System.Drawing.Size(10, 26);
            this.textSmaBi.TabIndex = 41;
            this.textSmaBi.Visible = false;
            // 
            // textLevy
            // 
            this.textLevy.Location = new System.Drawing.Point(1029, 102);
            this.textLevy.Name = "textLevy";
            this.textLevy.Size = new System.Drawing.Size(10, 26);
            this.textLevy.TabIndex = 42;
            this.textLevy.Visible = false;
            // 
            // textSearchOffer
            // 
            this.textSearchOffer.Location = new System.Drawing.Point(12, 44);
            this.textSearchOffer.Name = "textSearchOffer";
            this.textSearchOffer.Size = new System.Drawing.Size(10, 26);
            this.textSearchOffer.TabIndex = 43;
            this.textSearchOffer.Visible = false;
            // 
            // textOyaOffer
            // 
            this.textOyaOffer.Location = new System.Drawing.Point(28, 44);
            this.textOyaOffer.Name = "textOyaOffer";
            this.textOyaOffer.Size = new System.Drawing.Size(10, 26);
            this.textOyaOffer.TabIndex = 44;
            this.textOyaOffer.Visible = false;
            // 
            // textSmaOffer
            // 
            this.textSmaOffer.Location = new System.Drawing.Point(44, 44);
            this.textSmaOffer.Name = "textSmaOffer";
            this.textSmaOffer.Size = new System.Drawing.Size(10, 26);
            this.textSmaOffer.TabIndex = 45;
            this.textSmaOffer.Visible = false;
            // 
            // textTmaOffer
            // 
            this.textTmaOffer.Location = new System.Drawing.Point(60, 44);
            this.textTmaOffer.Name = "textTmaOffer";
            this.textTmaOffer.Size = new System.Drawing.Size(10, 26);
            this.textTmaOffer.TabIndex = 46;
            this.textTmaOffer.Visible = false;
            // 
            // textOmaOffer
            // 
            this.textOmaOffer.Location = new System.Drawing.Point(76, 44);
            this.textOmaOffer.Name = "textOmaOffer";
            this.textOmaOffer.Size = new System.Drawing.Size(10, 26);
            this.textOmaOffer.TabIndex = 47;
            this.textOmaOffer.Visible = false;
            // 
            // textYtdOffer
            // 
            this.textYtdOffer.Location = new System.Drawing.Point(92, 44);
            this.textYtdOffer.Name = "textYtdOffer";
            this.textYtdOffer.Size = new System.Drawing.Size(10, 26);
            this.textYtdOffer.TabIndex = 48;
            this.textYtdOffer.Visible = false;
            // 
            // textSiOffer
            // 
            this.textSiOffer.Location = new System.Drawing.Point(108, 44);
            this.textSiOffer.Name = "textSiOffer";
            this.textSiOffer.Size = new System.Drawing.Size(10, 26);
            this.textSiOffer.TabIndex = 49;
            this.textSiOffer.Visible = false;
            // 
            // textSiDate
            // 
            this.textSiDate.Location = new System.Drawing.Point(1045, 102);
            this.textSiDate.Name = "textSiDate";
            this.textSiDate.Size = new System.Drawing.Size(10, 26);
            this.textSiDate.TabIndex = 50;
            this.textSiDate.Visible = false;
            // 
            // textInceptMonth
            // 
            this.textInceptMonth.Location = new System.Drawing.Point(1063, 102);
            this.textInceptMonth.Name = "textInceptMonth";
            this.textInceptMonth.Size = new System.Drawing.Size(10, 26);
            this.textInceptMonth.TabIndex = 51;
            this.textInceptMonth.Visible = false;
            // 
            // textNav
            // 
            this.textNav.Location = new System.Drawing.Point(1079, 102);
            this.textNav.Name = "textNav";
            this.textNav.Size = new System.Drawing.Size(10, 26);
            this.textNav.TabIndex = 52;
            this.textNav.Visible = false;
            // 
            // textBi
            // 
            this.textBi.Location = new System.Drawing.Point(1095, 102);
            this.textBi.Name = "textBi";
            this.textBi.Size = new System.Drawing.Size(10, 26);
            this.textBi.TabIndex = 53;
            this.textBi.Visible = false;
            // 
            // labelBenchmarkLegendColour
            // 
            this.labelBenchmarkLegendColour.AutoSize = true;
            this.labelBenchmarkLegendColour.BackColor = System.Drawing.Color.LightSteelBlue;
            this.labelBenchmarkLegendColour.Location = new System.Drawing.Point(508, 729);
            this.labelBenchmarkLegendColour.Name = "labelBenchmarkLegendColour";
            this.labelBenchmarkLegendColour.Size = new System.Drawing.Size(17, 20);
            this.labelBenchmarkLegendColour.TabIndex = 54;
            this.labelBenchmarkLegendColour.Text = "  ";
            this.labelBenchmarkLegendColour.Click += new System.EventHandler(this.label11_Click);
            // 
            // labelBidBidLegendColour
            // 
            this.labelBidBidLegendColour.AutoSize = true;
            this.labelBidBidLegendColour.BackColor = System.Drawing.Color.SteelBlue;
            this.labelBidBidLegendColour.Location = new System.Drawing.Point(367, 729);
            this.labelBidBidLegendColour.Name = "labelBidBidLegendColour";
            this.labelBidBidLegendColour.Size = new System.Drawing.Size(17, 20);
            this.labelBidBidLegendColour.TabIndex = 55;
            this.labelBidBidLegendColour.Text = "  ";
            this.labelBidBidLegendColour.Click += new System.EventHandler(this.labelBidBidLegendColour_Click);
            // 
            // labelBenchmarkLegendText
            // 
            this.labelBenchmarkLegendText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelBenchmarkLegendText.AutoSize = true;
            this.labelBenchmarkLegendText.Location = new System.Drawing.Point(535, 729);
            this.labelBenchmarkLegendText.Name = "labelBenchmarkLegendText";
            this.labelBenchmarkLegendText.Size = new System.Drawing.Size(90, 20);
            this.labelBenchmarkLegendText.TabIndex = 56;
            this.labelBenchmarkLegendText.Text = "Benchmark";
            this.labelBenchmarkLegendText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelBidBidLegendText
            // 
            this.labelBidBidLegendText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelBidBidLegendText.AutoSize = true;
            this.labelBidBidLegendText.Location = new System.Drawing.Point(394, 729);
            this.labelBidBidLegendText.Name = "labelBidBidLegendText";
            this.labelBidBidLegendText.Size = new System.Drawing.Size(60, 20);
            this.labelBidBidLegendText.TabIndex = 57;
            this.labelBidBidLegendText.Text = "Bid-Bid";
            this.labelBidBidLegendText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.LargeChange = 1;
            this.hScrollBar1.Location = new System.Drawing.Point(914, 881);
            this.hScrollBar1.Maximum = 2;
            this.hScrollBar1.Minimum = 1;
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(52, 29);
            this.hScrollBar1.TabIndex = 58;
            this.hScrollBar1.Value = 1;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // labelPO
            // 
            this.labelPO.AutoSize = true;
            this.labelPO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.labelPO.ForeColor = System.Drawing.Color.MidnightBlue;
            this.labelPO.Location = new System.Drawing.Point(160, 189);
            this.labelPO.Name = "labelPO";
            this.labelPO.Size = new System.Drawing.Size(230, 25);
            this.labelPO.TabIndex = 59;
            this.labelPO.Text = "Performance Overview";
            // 
            // labelIndex
            // 
            this.labelIndex.AutoSize = true;
            this.labelIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.labelIndex.Location = new System.Drawing.Point(161, 223);
            this.labelIndex.Name = "labelIndex";
            this.labelIndex.Size = new System.Drawing.Size(424, 22);
            this.labelIndex.TabIndex = 60;
            this.labelIndex.Text = "Indexed Performance since Inception (Bid-Bid)";
            // 
            // labelSBText
            // 
            this.labelSBText.AutoSize = true;
            this.labelSBText.Location = new System.Drawing.Point(889, 921);
            this.labelSBText.Name = "labelSBText";
            this.labelSBText.Size = new System.Drawing.Size(90, 20);
            this.labelSBText.TabIndex = 61;
            this.labelSBText.Text = "Page 1 of 2";
            this.labelSBText.Click += new System.EventHandler(this.label17_Click);
            // 
            // chart2
            // 
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            legend2.Enabled = false;
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(132, 260);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.chart2.PaletteCustomColors = new System.Drawing.Color[] {
        System.Drawing.Color.SteelBlue};
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series2.IsValueShownAsLabel = true;
            series2.Label = "#VAL";
            series2.LabelBackColor = System.Drawing.Color.White;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart2.Series.Add(series2);
            this.chart2.Size = new System.Drawing.Size(708, 453);
            this.chart2.TabIndex = 62;
            this.chart2.Text = "chart2";
            this.chart2.Visible = false;
            this.chart2.Click += new System.EventHandler(this.chart2_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.60458F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.39542F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel2.Controls.Add(this.textFifthHSectorPercent, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.textFourthHSectorPercent, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.textTHSectorPercent, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.textSHSectorPercent, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.textFHSectorPercent, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.textFHSector, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.textFifthHName, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.textFHName, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.textSHName, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.textFourthHName, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.textTHName, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.textSHSector, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.textTHSector, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.textFourthHSector, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.textFifthHSector, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.labelTH, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(1019, 313);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.26087F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.73913F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(770, 237);
            this.tableLayoutPanel2.TabIndex = 63;
            this.tableLayoutPanel2.Visible = false;
            // 
            // textFifthHSectorPercent
            // 
            this.textFifthHSectorPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFifthHSectorPercent.BackColor = System.Drawing.Color.Gainsboro;
            this.textFifthHSectorPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFifthHSectorPercent.Location = new System.Drawing.Point(686, 207);
            this.textFifthHSectorPercent.Name = "textFifthHSectorPercent";
            this.textFifthHSectorPercent.Size = new System.Drawing.Size(80, 19);
            this.textFifthHSectorPercent.TabIndex = 82;
            this.textFifthHSectorPercent.Text = "10";
            this.textFifthHSectorPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textFourthHSectorPercent
            // 
            this.textFourthHSectorPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFourthHSectorPercent.BackColor = System.Drawing.Color.Gainsboro;
            this.textFourthHSectorPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFourthHSectorPercent.Location = new System.Drawing.Point(686, 167);
            this.textFourthHSectorPercent.Name = "textFourthHSectorPercent";
            this.textFourthHSectorPercent.Size = new System.Drawing.Size(80, 19);
            this.textFourthHSectorPercent.TabIndex = 81;
            this.textFourthHSectorPercent.Text = "10";
            this.textFourthHSectorPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textTHSectorPercent
            // 
            this.textTHSectorPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTHSectorPercent.BackColor = System.Drawing.Color.Gainsboro;
            this.textTHSectorPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTHSectorPercent.Location = new System.Drawing.Point(686, 128);
            this.textTHSectorPercent.Name = "textTHSectorPercent";
            this.textTHSectorPercent.Size = new System.Drawing.Size(80, 19);
            this.textTHSectorPercent.TabIndex = 80;
            this.textTHSectorPercent.Text = "10";
            this.textTHSectorPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textSHSectorPercent
            // 
            this.textSHSectorPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSHSectorPercent.BackColor = System.Drawing.Color.Gainsboro;
            this.textSHSectorPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSHSectorPercent.Location = new System.Drawing.Point(686, 88);
            this.textSHSectorPercent.Name = "textSHSectorPercent";
            this.textSHSectorPercent.Size = new System.Drawing.Size(80, 19);
            this.textSHSectorPercent.TabIndex = 79;
            this.textSHSectorPercent.Text = "20";
            this.textSHSectorPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textFHSectorPercent
            // 
            this.textFHSectorPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFHSectorPercent.BackColor = System.Drawing.Color.Gainsboro;
            this.textFHSectorPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFHSectorPercent.Location = new System.Drawing.Point(686, 49);
            this.textFHSectorPercent.Name = "textFHSectorPercent";
            this.textFHSectorPercent.Size = new System.Drawing.Size(80, 19);
            this.textFHSectorPercent.TabIndex = 78;
            this.textFHSectorPercent.Text = "30";
            this.textFHSectorPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textFHSector
            // 
            this.textFHSector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFHSector.BackColor = System.Drawing.Color.Gainsboro;
            this.textFHSector.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFHSector.Location = new System.Drawing.Point(424, 49);
            this.textFHSector.Name = "textFHSector";
            this.textFHSector.Size = new System.Drawing.Size(255, 19);
            this.textFHSector.TabIndex = 73;
            this.textFHSector.Text = "FINANCIAL SERVICES";
            // 
            // textFifthHName
            // 
            this.textFifthHName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFifthHName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFifthHName.Location = new System.Drawing.Point(4, 207);
            this.textFifthHName.Name = "textFifthHName";
            this.textFifthHName.Size = new System.Drawing.Size(413, 19);
            this.textFifthHName.TabIndex = 73;
            this.textFifthHName.Text = "STARHUB LTD";
            // 
            // textFHName
            // 
            this.textFHName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFHName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFHName.Location = new System.Drawing.Point(4, 49);
            this.textFHName.Name = "textFHName";
            this.textFHName.Size = new System.Drawing.Size(413, 19);
            this.textFHName.TabIndex = 64;
            this.textFHName.Text = "DBS GROUP HOLDINGS LTD";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(686, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 44);
            this.label3.TabIndex = 66;
            this.label3.Text = "%";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(424, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(255, 44);
            this.label2.TabIndex = 65;
            this.label2.Text = "Sector";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textSHName
            // 
            this.textSHName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSHName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSHName.Location = new System.Drawing.Point(4, 88);
            this.textSHName.Name = "textSHName";
            this.textSHName.Size = new System.Drawing.Size(413, 19);
            this.textSHName.TabIndex = 67;
            this.textSHName.Text = "SINGTEL TELECOMMUNICATIONS LIMITED";
            this.textSHName.TextChanged += new System.EventHandler(this.textSHName_TextChanged);
            // 
            // textFourthHName
            // 
            this.textFourthHName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFourthHName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFourthHName.Location = new System.Drawing.Point(4, 167);
            this.textFourthHName.Name = "textFourthHName";
            this.textFourthHName.Size = new System.Drawing.Size(413, 19);
            this.textFourthHName.TabIndex = 69;
            this.textFourthHName.Text = "OVERSEA-CHINESE BANKING CORPORATION LIMITED";
            // 
            // textTHName
            // 
            this.textTHName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTHName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTHName.Location = new System.Drawing.Point(4, 128);
            this.textTHName.Name = "textTHName";
            this.textTHName.Size = new System.Drawing.Size(413, 19);
            this.textTHName.TabIndex = 68;
            this.textTHName.Text = "UNITED OVERSEAS BANK LIMITED";
            // 
            // textSHSector
            // 
            this.textSHSector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textSHSector.BackColor = System.Drawing.Color.Gainsboro;
            this.textSHSector.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textSHSector.Location = new System.Drawing.Point(424, 88);
            this.textSHSector.Name = "textSHSector";
            this.textSHSector.Size = new System.Drawing.Size(255, 19);
            this.textSHSector.TabIndex = 74;
            this.textSHSector.Text = "COMMUNICATION SERVICES";
            // 
            // textTHSector
            // 
            this.textTHSector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTHSector.BackColor = System.Drawing.Color.Gainsboro;
            this.textTHSector.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTHSector.Location = new System.Drawing.Point(424, 128);
            this.textTHSector.Name = "textTHSector";
            this.textTHSector.Size = new System.Drawing.Size(255, 19);
            this.textTHSector.TabIndex = 75;
            this.textTHSector.Text = "FINANCIAL SERVICES";
            // 
            // textFourthHSector
            // 
            this.textFourthHSector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFourthHSector.BackColor = System.Drawing.Color.Gainsboro;
            this.textFourthHSector.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFourthHSector.Location = new System.Drawing.Point(424, 167);
            this.textFourthHSector.Name = "textFourthHSector";
            this.textFourthHSector.Size = new System.Drawing.Size(255, 19);
            this.textFourthHSector.TabIndex = 76;
            this.textFourthHSector.Text = "FINANCIAL SERVICES";
            // 
            // textFifthHSector
            // 
            this.textFifthHSector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textFifthHSector.BackColor = System.Drawing.Color.Gainsboro;
            this.textFifthHSector.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textFifthHSector.Location = new System.Drawing.Point(424, 207);
            this.textFifthHSector.Name = "textFifthHSector";
            this.textFifthHSector.Size = new System.Drawing.Size(255, 19);
            this.textFifthHSector.TabIndex = 77;
            this.textFifthHSector.Text = "COMMUNICATION SERVICES";
            // 
            // labelTH
            // 
            this.labelTH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelTH.AutoSize = true;
            this.labelTH.BackColor = System.Drawing.Color.Transparent;
            this.labelTH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTH.Location = new System.Drawing.Point(4, 1);
            this.labelTH.Name = "labelTH";
            this.labelTH.Size = new System.Drawing.Size(413, 44);
            this.labelTH.TabIndex = 64;
            this.labelTH.Text = "Top 5 Holdings";
            this.labelTH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90.89727F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.102731F));
            this.tableLayoutPanel3.Controls.Add(this.textTotalPercent, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(1019, 548);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(770, 34);
            this.tableLayoutPanel3.TabIndex = 72;
            this.tableLayoutPanel3.Visible = false;
            // 
            // textTotalPercent
            // 
            this.textTotalPercent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textTotalPercent.BackColor = System.Drawing.Color.LightSteelBlue;
            this.textTotalPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textTotalPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTotalPercent.Location = new System.Drawing.Point(702, 4);
            this.textTotalPercent.Name = "textTotalPercent";
            this.textTotalPercent.Size = new System.Drawing.Size(64, 19);
            this.textTotalPercent.TabIndex = 83;
            this.textTotalPercent.Text = "80";
            this.textTotalPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(4, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(691, 32);
            this.label4.TabIndex = 65;
            this.label4.Text = "Total";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // SearchData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1912, 1038);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.labelSBText);
            this.Controls.Add(this.labelIndex);
            this.Controls.Add(this.labelPO);
            this.Controls.Add(this.hScrollBar1);
            this.Controls.Add(this.labelBidBidLegendText);
            this.Controls.Add(this.labelBenchmarkLegendText);
            this.Controls.Add(this.labelBidBidLegendColour);
            this.Controls.Add(this.labelBenchmarkLegendColour);
            this.Controls.Add(this.textBi);
            this.Controls.Add(this.textNav);
            this.Controls.Add(this.textInceptMonth);
            this.Controls.Add(this.textSiDate);
            this.Controls.Add(this.textSiOffer);
            this.Controls.Add(this.textYtdOffer);
            this.Controls.Add(this.textOmaOffer);
            this.Controls.Add(this.textTmaOffer);
            this.Controls.Add(this.textSmaOffer);
            this.Controls.Add(this.textOyaOffer);
            this.Controls.Add(this.textSearchOffer);
            this.Controls.Add(this.textLevy);
            this.Controls.Add(this.textSmaBi);
            this.Controls.Add(this.textOyaBi);
            this.Controls.Add(this.textTmaBi);
            this.Controls.Add(this.textOmaBi);
            this.Controls.Add(this.textYtdBi);
            this.Controls.Add(this.textSiBi);
            this.Controls.Add(this.textSearchBi);
            this.Controls.Add(this.textInceptYear);
            this.Controls.Add(this.textSiNav);
            this.Controls.Add(this.textYtdNav);
            this.Controls.Add(this.textOmaNav);
            this.Controls.Add(this.textTmaNav);
            this.Controls.Add(this.textSmaNav);
            this.Controls.Add(this.textSearchNav);
            this.Controls.Add(this.textOyaNav);
            this.Controls.Add(this.textSearchDate);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.labelSearchData);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.MaximizeBox = false;
            this.Name = "SearchData";
            this.Text = "ABC Asset Management Fund Fact Sheet Generator";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelSearchData;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelBB;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label labelOB;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelPH;
        private System.Windows.Forms.Label labelYtd;
        private System.Windows.Forms.Label labelOM;
        private System.Windows.Forms.Label labelTM;
        private System.Windows.Forms.Label labelSM;
        private System.Windows.Forms.Label labelOY;
        private System.Windows.Forms.Label labelSI;
        private System.Windows.Forms.TextBox textSearchDate;
        private System.Windows.Forms.TextBox textOyaNav;
        private System.Windows.Forms.TextBox textOyaBidBid;
        private System.Windows.Forms.TextBox textSearchNav;
        private System.Windows.Forms.TextBox textSmaNav;
        private System.Windows.Forms.TextBox textTmaNav;
        private System.Windows.Forms.TextBox textOmaNav;
        private System.Windows.Forms.TextBox textYtdNav;
        private System.Windows.Forms.TextBox textSiNav;
        private System.Windows.Forms.TextBox textSiBidBid;
        private System.Windows.Forms.TextBox textYtdBidBid;
        private System.Windows.Forms.TextBox textOmaBidBid;
        private System.Windows.Forms.TextBox textTmaBidBid;
        private System.Windows.Forms.TextBox textSmaBidBid;
        private System.Windows.Forms.TextBox textInceptYear;
        private System.Windows.Forms.TextBox textSearchBi;
        private System.Windows.Forms.TextBox textSiBi;
        private System.Windows.Forms.TextBox textYtdBi;
        private System.Windows.Forms.TextBox textOmaBi;
        private System.Windows.Forms.TextBox textTmaBi;
        private System.Windows.Forms.TextBox textOyaBi;
        private System.Windows.Forms.TextBox textSmaBi;
        private System.Windows.Forms.TextBox textOyaBenchmark;
        private System.Windows.Forms.TextBox textOmaBenchmark;
        private System.Windows.Forms.TextBox textSiBenchmark;
        private System.Windows.Forms.TextBox textSmaBenchmark;
        private System.Windows.Forms.TextBox textTmaBenchmark;
        private System.Windows.Forms.TextBox textYtdBenchmark;
        private System.Windows.Forms.TextBox textLevy;
        private System.Windows.Forms.TextBox textSearchOffer;
        private System.Windows.Forms.TextBox textOyaOffer;
        private System.Windows.Forms.TextBox textSmaOffer;
        private System.Windows.Forms.TextBox textTmaOffer;
        private System.Windows.Forms.TextBox textOmaOffer;
        private System.Windows.Forms.TextBox textYtdOffer;
        private System.Windows.Forms.TextBox textSiOffer;
        private System.Windows.Forms.TextBox textSiOfferBid;
        private System.Windows.Forms.TextBox textOyaOfferBid;
        private System.Windows.Forms.TextBox textSmaOfferBid;
        private System.Windows.Forms.TextBox textTmaOfferBid;
        private System.Windows.Forms.TextBox textOmaOfferBid;
        private System.Windows.Forms.TextBox textYtdOfferBid;
        private System.Windows.Forms.TextBox textSiDate;
        private System.Windows.Forms.TextBox textInceptMonth;
        private System.Windows.Forms.TextBox textNav;
        private System.Windows.Forms.TextBox textBi;
        private System.Windows.Forms.Label labelBenchmarkLegendColour;
        private System.Windows.Forms.Label labelBidBidLegendColour;
        private System.Windows.Forms.Label labelBenchmarkLegendText;
        private System.Windows.Forms.Label labelBidBidLegendText;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.Label labelPO;
        private System.Windows.Forms.Label labelIndex;
        private System.Windows.Forms.Label labelSBText;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label labelTH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textFHName;
        private System.Windows.Forms.TextBox textSHName;
        private System.Windows.Forms.TextBox textTHName;
        private System.Windows.Forms.TextBox textFourthHName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textFifthHName;
        private System.Windows.Forms.TextBox textFHSector;
        private System.Windows.Forms.TextBox textSHSector;
        private System.Windows.Forms.TextBox textTHSector;
        private System.Windows.Forms.TextBox textFourthHSector;
        private System.Windows.Forms.TextBox textFifthHSector;
        private System.Windows.Forms.TextBox textFHSectorPercent;
        private System.Windows.Forms.TextBox textSHSectorPercent;
        private System.Windows.Forms.TextBox textTHSectorPercent;
        private System.Windows.Forms.TextBox textFourthHSectorPercent;
        private System.Windows.Forms.TextBox textFifthHSectorPercent;
        private System.Windows.Forms.TextBox textTotalPercent;
    }
}